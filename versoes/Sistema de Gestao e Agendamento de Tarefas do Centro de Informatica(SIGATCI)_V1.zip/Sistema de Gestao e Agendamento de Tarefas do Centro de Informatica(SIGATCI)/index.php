<!DOCTYPE html>
<html lang="pt-pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SIGATCIUP - Centro de Informática UP</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet">
        <link rel="shortcut icon" href="imagens/image.ico" type="image/x-icon">

        <style>
            :root {
                --cor-da-up: #004d40;
                --brilho-institucional: #0056b3;
                --nuvem-suave: #f8f9fa;
            }

            body {
                font-family: 'Nunito', sans-serif;
                background-color: var(--nuvem-suave);
            }

            /* O Palco Principal (Hero Section) */
            .palco-de-entrada {
                background: linear-gradient(rgba(0, 77, 64, 0.85), rgba(0, 86, 179, 0.75)), url('imagens/imagem.png');
                background-size: cover;
                background-position: center;
                color: white;
                padding: 120px 0;
                text-align: center;
                clip-path: ellipse(150% 100% at 50% 0%); /* Efeito visual moderno no fundo */
            }

            .barra-de-cima {
                background-color: white !important;
                border-bottom: 3px solid var(--cor-da-up);
            }

            .emblema-vivo img { height: 70px; transition: 0.5s; }
            .emblema-vivo img:hover { transform: rotate(5deg) scale(1.1); }

            /* Cartões de números (Estatísticas) */
            .caixa-de-impacto {
                border: none;
                border-radius: 20px;
                background: white;
                transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            }

            .caixa-de-impacto:hover {
                transform: scale(1.05);
                box-shadow: 0 15px 45px rgba(0,0,0,0.15);
            }

            /* O botão de entrada */
            .chave-mestra {
                background-color: var(--cor-da-up);
                color: white;
                padding: 14px 40px;
                border-radius: 50px;
                font-weight: 800;
                text-transform: uppercase;
                letter-spacing: 1px;
                transition: 0.3s;
                border: 2px solid transparent;
            }

            .chave-mestra:hover {
                background-color: transparent;
                border-color: var(--cor-da-up);
                color: var(--cor-da-up);
            }

            /* Lista de coisas acontecendo (Tarefas fakes) */
            .batida-do-trabalho {
                border-left: 6px solid var(--brilho-institucional);
                background: white;
                margin-bottom: 15px;
                padding: 20px;
                border-radius: 10px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .selo-de-andamento {
                font-size: 0.8rem;
                padding: 5px 15px;
                border-radius: 20px;
                font-weight: bold;
            }

            .rodape-final {
                background-color: #1a1a1a;
                color: #888;
                padding: 40px 0;
            }
        </style>
    </head>
    <body>

        <nav class="navbar navbar-expand-lg barra-de-cima sticky-top">
            <div class="container">
                <a class="navbar-brand emblema-vivo" href="#">
                    <img src="imagens/imagem.png" alt="UP Maputo">
                    <span class="ms-3 fw-bold text-dark fs-4">SIGATCIUP</span>
                </a>
                <div class="ms-auto">
                    <a href="login.php" class="btn chave-mestra">Abrir Portal</a>
                </div>
            </div>
        </nav>

        <header class="palco-de-entrada">
            <div class="container">
                <h1 class="display-3 fw-bold mb-3">Sistema de Gestão e Agendamento de Tarefas do CIUP</h1>
                <p class="fs-4">Acompanhamento em tempo real das metas da nossa instituição.</p>
            </div>
        </header>

        <section class="container" style="margin-top: -50px;">
            <div class="row text-center">
                <div class="col-md-4 mb-4">
                    <div class="p-4 caixa-de-impacto">
                        <h2 class="display-5 fw-bold text-success">92%</h2>
                        <h5 class="text-uppercase small fw-bold">Pulso Anual</h5>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="p-4 caixa-de-impacto">
                        <h2 class="display-5 fw-bold text-primary">145</h2>
                        <h5 class="text-uppercase small fw-bold">Tarefas Vencidas</h5>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="p-4 caixa-de-impacto">
                        <h2 class="display-5 fw-bold text-warning">08</h2>
                        <h5 class="text-uppercase small fw-bold">Frentes Ativas</h5>
                    </div>
                </div>
            </div>
        </section>

        <section class="container my-5">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">O que está a acontecer agora?</h2>
                    
                    <div class="batida-do-trabalho shadow-sm">
                        <div>
                            <span class="text-muted d-block small">Redes</span>
                            <strong>Ajuste de Sinal Wireless - Campus Lhanguene</strong>
                        </div>
                        <span class="selo-de-andamento bg-success text-white">Pronto</span>
                    </div>

                    <div class="batida-do-trabalho shadow-sm">
                        <div>
                            <span class="text-muted d-block small">Informática</span>
                            <strong>Configuração de Backup de Dados Anuais</strong>
                        </div>
                        <span class="selo-de-andamento bg-warning text-dark">Em Processo</span>
                    </div>

                    <div class="batida-do-trabalho shadow-sm">
                        <div>
                            <span class="text-muted d-block small">Secretaria</span>
                            <strong>Triagem de Documentos via IA/OCR</strong>
                        </div>
                        <span class="selo-de-andamento bg-primary text-white">Em Fila</span>
                    </div>
                </div>
                
                <div class="col-lg-6 mt-5 mt-lg-0">
                    <div class="bg-white p-2 rounded shadow-lg">
                        <div style="background: #f0f0f0; height: 300px; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                            <img src="imagens/imagem.png" style="max-height: 150px; filter: grayscale(1); opacity: 0.3;" alt="Gráfico">
                            <p class="position-absolute fw-bold text-muted">Mapa de Desempenho Anual</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <footer class="rodape-final text-center">
            <div class="container">
                <p class="mb-0 fw-bold">Universidade Pedagógica de Maputo</p>
                <p class="small opacity-50">Centro de Informática - SIGATCI 2026</p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>