function revisarDados() {
    const nome = document.getElementById('nome').value;
    const bi = document.getElementById('bi').value;
    const depto = document.getElementById('departamento').value;
    const cargo = document.getElementById('cargo').value;

    const biRegex = /^[0-9]{12}[A-Z]{1}$/;
    
    if(!biRegex.test(bi)) {
        mostrarNotificacao("Erro: BI inválido (12 números e 1 letra maiúscula).", "#d32f2f");
        return;
    }

    if(nome === "" || cargo === "") {
        mostrarNotificacao("Erro: Preencha todos os campos obrigatórios.", "#d32f2f");
        return;
    }

    const resumo = `
        <div style="text-align: left; background: #f4f7f6; padding: 15px; border-radius: 8px; border-left: 5px solid #004d40;">
            <p><strong>Nome:</strong> ${nome}</p>
            <p><strong>BI:</strong> ${bi}</p>
            <p><strong>Departamento:</strong> ${depto}</p>
            <p><strong>Cargo:</strong> ${cargo}</p>
            <hr>
            <p style="color: #666; font-size: 0.85em;">O código de acesso e senha serão gerados automaticamente pelo sistema.</p>
        </div>
    `;
    
    document.getElementById('dadosResumo').innerHTML = resumo;
    document.getElementById('modalRevisao').style.display = 'flex';
}

function fecharModal() {
    document.getElementById('modalRevisao').style.display = 'none';
}

function mostrarNotificacao(texto, cor) {
    const notif = document.getElementById('notificacao');
    if(notif) {
        notif.innerText = texto;
        notif.style.background = cor;
        notif.style.top = '0';
        setTimeout(() => { notif.style.top = '-100px'; }, 5000);
    }
}

function enviarParaBD() {
    fecharModal();
    const form = document.getElementById('formCadastro');
    
    // Captura os dados do formulário automaticamente usando os names dos inputs
    const dadosForm = new FormData(form);

    fetch('../acoes_php_BD/cadastro_funcionario.php', {
        method: 'POST',
        body: dadosForm
    })
    .then(response => response.json())
    .then(data => {
        if (data.sucesso) {
            mostrarNotificacao(`Sucesso! Código Gerado: ${data.codigo}`, "#004d40");
            form.reset();
        } else {
            mostrarNotificacao("Erro: " + data.mensagem, "#d32f2f");
        }
    })
    .catch(error => {
        mostrarNotificacao("Erro de ligação com o servidor.", "#000");
        console.error("Erro no Fetch:", error);
    });
}