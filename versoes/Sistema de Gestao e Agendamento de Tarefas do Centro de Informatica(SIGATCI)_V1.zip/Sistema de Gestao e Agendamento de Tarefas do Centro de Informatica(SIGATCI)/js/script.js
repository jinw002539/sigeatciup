function fecharModal() {
    const modal = document.getElementById('modalErro');
    if (modal) {
        modal.style.display = 'none';
    }
    // Limpa o "?erro=1" sem sair do login.php
    window.history.replaceState({}, document.title, window.location.pathname);
}

// Fecha se clicar fora da caixa branca
window.onclick = function(event) {
    let modal = document.getElementById('modalErro');
    if (event.target == modal) {
        fecharModal();
    }
}