<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SIGATCI - Senha</title>
        <link rel="stylesheet" href="../css/senha.css">
        <link rel="shortcut icon" href="../imagens/image.ico" type="image/x-icon">
    </head>
    <body>
        <h1 class="titulo">Sistema de Gestão e Agendamento de Tarefas do Centro de Informática</h1>
        <img src="../imagens/imagem.png">
        <p>Introduza o seu contacto</p>
        <form action="" method="get">
            <input type="text" max="9" id="senhaRecuperar" placeholder="+258 8* *** ****">
            <button type="submit">Enviar pedido</button>
        </form>
        <a href="../login.php">Voltar ao Login</a>
        <footer>&copy 2026 - Direitos reservados</footer>
    </body>
</html>