<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro - SIGATCIUP</title>
        <link rel="stylesheet" href="../css/cadastro_funcionario.css">
        <link rel="shortcut icon" href="../imagens/image.ico" type="image/x-icon">
    </head>
    <body>

        <div id="notificacao"></div>

        <div class="barra-lateral">
            <h2>SIGATCIUP</h2>
            <a href="../dashboards/dashboard_admin.php" class="item-menu">HOME</a>
            <a href="#" class="item-menu ativo">CADASTRAR FUNCIONÁRIO</a>
            <!-- <a href="../logout.php" class="item-menu sair">SAIR</a> -->
        </div>

        <div class="palco-principal">
            <div class="cartao-cadastro">
                <h1>Cadastro de novo funcionário</h1>
                <form id="formCadastro" onsubmit="event.preventDefault();">
                    <div class="campo-grupo">
                        <label>Nome Completo</label>
                        <input type="text" id="nome" name="nome" required>
                    </div>
                    
                    <div class="campo-grupo">
                        <label>Gênero</label>
                        <select id="genero" name="genero">
                            <option value="masculino">Masculino</option>
                            <option value="feminino">Feminino</option>
                        </select>
                    </div>

                    <div class="campo-grupo">
                        <label>Número do BI</label>
                        <input type="text" id="bi" name="BI" maxlength="13" required>
                    </div>

                    <div class="campo-grupo">
                        <label>Data de Nascimento</label>
                        <input type="date" id="data_nas" name="data_nas" required>
                    </div>

                    <div class="campo-grupo">
                        <label>Departamento</label>
                        <select id="departamento" name="departamento">
                            <option value="Redes">Redes</option>
                            <option value="Sistemas">Sistemas</option>
                            <option value="Recursos Humanos">Recursos Humanos</option>
                        </select>
                    </div>

                    <div class="campo-grupo">
                        <label>Cargo / Área</label>
                        <input type="text" id="cargo" name="cargo" required>
                    </div>

                    <button type="button" class="botao-confirmar" onclick="revisarDados()">REVISAR E CADASTRAR</button>
                </form>
            </div>
        </div>

        <div id="modalRevisao" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); z-index:1000; justify-content:center; align-items:center;">
            <div style="background:white; padding:30px; border-radius:15px; max-width:400px; width:90%;">
                <h3>Confirmar Dados?</h3>
                <div id="dadosResumo" style="margin-bottom:20px; font-size:0.9rem; line-height:1.6; color: #333;"></div>
                <div style="display: flex; gap: 10px;">
                    <button onclick="enviarParaBD()" style="flex:1; background:#004d40; color:white; border:none; padding:12px; border-radius:5px; cursor:pointer;">Confirmar e Salvar</button>
                    <button onclick="fecharModal()" style="flex:1; background:#d32f2f; color:white; border:none; padding:12px; border-radius:5px; cursor:pointer;">Cancelar</button>
                </div>
            </div>
        </div>

        <script src="../js/funcionario_cadastro.js"></script>
    </body>
</html>