<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login SIGATCIUP</title>
        <link rel="stylesheet" href="css/login.css">
        <link rel="shortcut icon" href="imagens/image.ico" type="image/x-icon">
    </head>
    
    <body>
        <div class="tudo">
            <header>
                <h1 class="titulo">Sistema de Gestão e Agendamento de Tarefas do CIUP</h1>
            </header>
            <main>
                <div class="imgform">
                    <img src="imagens/imagem.png" alt="Logotipo do UP">
                    <form action="acoes_php_BD/login_acao.php" method="post">
                    <div class="caixinha">
                        <input type="text" name="codigo" id="codigo" placeholder="Código" required>
                        <input type="password" name="senha" id="senha" placeholder="Senha" required>
                        <button type="submit">Autenticar</button>
                    </div>
                </form>
                </div>
            </main>
            <a href="../recuperacao_senha/senha.php" style="display: block; text-align: center; margin-top: 20px;">Esqueci a senha</a>
            <a href="index.php" style="display: block; text-align: center; margin-top: 20px;">Voltar a pagina inicial</a>
            <footer style="text-align: center; margin-top: 30px;">&copy; 2026 - Direitos reservados</footer>
        </div>

      <div id="modalErro" class="modal">
            <div class="modal-content">
                <span class="close-btn" onclick="fecharModal()">&times;</span>
                <p><strong>Erro de Autenticação!</strong></p>
                <p>O Código ou a Senha introduzidos estão incorretos.</p>
                <button class="modal-button" onclick="fecharModal()">Tentar Novamente</button>
            </div>
        </div>

        <?php if (isset($_GET['erro'])): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById('modalErro').style.display = 'block';
            });
        </script>
        <?php endif; ?>

        <script src="js/script.js"></script>
    </body>
</html>