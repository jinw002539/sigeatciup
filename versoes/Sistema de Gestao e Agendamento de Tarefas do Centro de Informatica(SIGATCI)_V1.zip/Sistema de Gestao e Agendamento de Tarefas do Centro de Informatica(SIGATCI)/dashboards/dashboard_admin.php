<?php
    session_start();
    // Proteção de Cache e Sessão
    header("Cache-Control: no-cache, no-store, must-revalidate");
    if (!isset($_SESSION['adminLog']) || $_SESSION['adminLog'] !== true) {
        header("Location: login.php");
        exit();
    }
    $nomeAdmin = $_SESSION['adminNome'];
?>

<!DOCTYPE html>
<html lang="pt">
    <head>
        <meta charset="UTF-8">
        <title>Painel Admin - SIGATCIUP</title>
        <link rel="stylesheet" href="../css/dashboard_admin.css">
        <link rel="shortcut icon" href="../imagens/image.ico" type="image/x-icon">

    </head>
    <body>

        <div class="barra-lateral">
            <div class="logo-area">
                <h2>SIGATCIUP</h2>
                <small>Sistema de Gestão</small>
            </div>
            
            <nav class="nav-menu">
                <a href="#" class="item-menu ativo">HOME</a>
                <a href="../cadastro/funcionario.php" class="item-menu">FUNCIONÁRIOS</a>
                <a href="#" class="item-menu">TAREFAS</a>
                <!-- <a href="#" class="item-menu">VER TAREFAS SEMESTRAIS</a> -->
                <!-- <a href="#" class="item-menu">VER TODOS FUNCIONÁRIOS</a> -->
                <a href="#" class="item-menu">DIRETORES</a>
                <a href="#" class="item-menu">RELATÓRIOS (PDF)</a>
                
                <a href="../logout.php" class="item-menu sair">SAIR DO SISTEMA</a>
            </nav>
        </div>

        <div class="conteudo-principal">
            <div class="cabecalho-boas-vindas">
                <h1>Olá, Diretor(a) <?php echo $nomeAdmin; ?></h1>
                <p>Bem-vindo ao painel central de controlo do CIUP.</p>
            </div>

            <div class="grid-estatisticas">
                <div class="card-info">
                    <h3>Funcionários</h3>
                    <div class="numero">13</div>
                </div>
                <div class="card-info">
                    <h3>Tarefas Anuais</h3>
                    <div class="numero">140</div>
                </div>
                <div class="card-info">
                    <h3>Trimestre I</h3>
                    <div class="numero">50</div>
                </div>
                <div class="card-info">
                    <h3>D. Redes</h3>
                    <div class="numero">16</div>
                </div>
                <div class="card-info">
                    <h3>D. Sistemas</h3>
                    <div class="numero">18</div>
                </div>
            </div>
        </div>

    </body>
</html>