<?php
    session_start();
    
    // Limpa todas as variáveis da sessão
    $_SESSION = array();

    // Se desejar destruir o cookie da sessão também (mais seguro)
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 5000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    // Destrói a sessão no servidor
    session_destroy();

    // Redireciona para o login com um parâmetro para evitar cache na volta
    header("Location: login.php?saida=sucesso");
    exit();
?>