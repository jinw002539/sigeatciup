<?php
    header('Content-Type: application/json');
    session_start();
    require_once("../data/config.php");

    // Protecao para drs
    if(!isset($_SESSION['adminLog'])){
        echo json_encode(['sucesso' => false, 'mensagem' => 'Acesso negado.']);
        exit();
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        try {
            $nome = $_POST['nome'];
            $bi = $_POST['BI'];
            $genero = ($_POST['genero'] == 'masculino') ? 'M' : 'F';
            $data_nas = $_POST['data_nas'];
            $dept = $_POST['departamento'];
            $cargo = $_POST['cargo'];

            $nivel = "01";
            $random = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
            $ano = date('Y');
            $codigoGerado = "$nivel.$random.$ano";
            
            $senhaInicial = $codigoGerado; 

            $sql = "INSERT INTO funcionarios (nome, genero, bi, data_nascimento, departamento, cargo, codigo_acesso, senha_hash, status) 
                    VALUES (:nome, :genero, :bi, :data_nas, :dept, :cargo, :codigo, :senha, true)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'nome' => $nome,
                'genero' => $genero,
                'bi' => $bi,
                'data_nas' => $data_nas,
                'dept' => $dept,
                'cargo' => $cargo,
                'codigo' => $codigoGerado,
                'senha' => $senhaInicial
            ]);

            echo json_encode([
                'sucesso' => true, 
                'codigo' => $codigoGerado,
                'mensagem' => 'Funcionário cadastrado com sucesso!'
            ]);

        } catch (PDOException $e) {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Erro no Banco de Dados: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['sucesso' => false, 'mensagem' => 'Método inválido.']);
    }
    exit();