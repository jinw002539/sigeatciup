<?php
    session_start();
    require_once '../data/config.php'; 

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $usercode = $_POST['codigo'];
        $password = $_POST['senha'];

        try {
            $sql = "SELECT nome, senha_hash FROM directores WHERE codigo_acesso = :codigo AND status = true";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['codigo' => $usercode]);
            $admin = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verifica se encontrou e se a senha coincide
            if ($admin && $password === $admin['senha_hash']) {
                $_SESSION['adminLog'] = true;
                $_SESSION['adminNome'] = $admin['nome'];
                header("Location: ../dashboards/dashboard_admin.php");
                exit();
            } else {
                // Se falhar, volta com o erro que o teu JS já trata para abrir o Modal
                header("Location: ../login.php?erro=1");
                exit();
            }

        } catch (PDOException $e) {
            die("Erro ao consultar base de dados: " . $e->getMessage());
        }
    } else {
        header("Location: ../login.php");
        exit();
    }
?>