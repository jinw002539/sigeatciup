<div class="palco-principal">
    <div class="cartao-lista">
        <div class="cabecalho-tarefas">
            <h1>Plano de Atividades - CIUP</h1>
            <div class="filtros">
                <select id="filtro-periodo" onchange="filtrarTarefas()">
                    <option value="todos">Todos os Períodos</option>
                    <option value="t1">1º Trimestre (Jan-Mar)</option>
                    <option value="t2">2º Trimestre (Abr-Jun)</option>
                    <option value="s1">1º Semestre (Jan-Jun)</option>
                </select>
                <button class="btn-novo" onclick="abrirModalTarefa()">+ Nova Atividade</button>
            </div>
        </div>

        <table class="tabela-estilizada">
            <thead>
                <tr>
                    <th>Actividade</th>
                    <th>Objectivos</th>
                    <th>Resultado Esperado</th>
                    <th>Prazo</th>
                    <th>Estado</th>
                    <th class="text-center">Ações</th>
                </tr>
            </thead>
            <tbody id="tabelaTarefasCorpo">
                </tbody>
        </table>
    </div>
</div>