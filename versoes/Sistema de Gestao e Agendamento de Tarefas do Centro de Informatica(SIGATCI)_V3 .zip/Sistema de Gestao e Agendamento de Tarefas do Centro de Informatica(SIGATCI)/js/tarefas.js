function carregarTarefas(filtro = 'todos') {
    fetch(`../acoes_php_BD/tarefa_logica.php?listar=true&periodo=${filtro}`)
        .then(r => r.json())
        .then(res => {
            const corpo = document.getElementById('tabelaTarefasCorpo');
            corpo.innerHTML = "";

            res.dados.forEach(t => {
                corpo.innerHTML += `
                    <tr>
                        <td>${t.actividade}</td>
                        <td><small>${t.objectivos}</small></td>
                        <td>${t.resultado_esperado}</td>
                        <td>${formatarData(t.prazo_execucao)}</td>
                        <td><span class="badge-${t.estado.replace(' ', '-')}">${t.estado}</span></td>
                        <td class="text-center">
                            <button title="Atribuir" onclick="abrirAtribuicao(${t.id})"><i class="bi bi-person-plus"></i></button>
                            <button title="Cancelar" class="text-danger" onclick="cancelarTarefa(${t.id})"><i class="bi bi-x-circle"></i></button>
                        </td>
                    </tr>
                `;
            });
        });
}

function filtrarTarefas() {
    const periodo = document.getElementById('filtro-periodo').value;
    carregarTarefas(periodo);
}