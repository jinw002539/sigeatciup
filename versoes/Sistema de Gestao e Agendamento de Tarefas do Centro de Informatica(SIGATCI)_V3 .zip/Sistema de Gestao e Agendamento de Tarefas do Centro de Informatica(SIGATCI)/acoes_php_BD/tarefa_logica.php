if (isset($_GET['listar'])) {
    $periodo = $_GET['periodo'];
    $where = "WHERE true";

    // Lógica para filtrar por trimestres/semestres
    if ($periodo == 't1') $where .= " AND EXTRACT(MONTH FROM prazo_execucao) BETWEEN 1 AND 3";
    if ($periodo == 's1') $where .= " AND EXTRACT(MONTH FROM prazo_execucao) BETWEEN 1 AND 6";

    $sql = "SELECT * FROM tarefas $where ORDER BY prazo_execucao ASC";
    // ... executa pdo e retorna json
}