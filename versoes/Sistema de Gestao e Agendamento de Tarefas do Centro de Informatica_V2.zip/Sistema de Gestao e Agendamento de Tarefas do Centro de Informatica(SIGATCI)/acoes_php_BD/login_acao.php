<?php
session_start();
require_once('../data/config.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php');
    exit();
}

$codigo = $_POST['codigo'] ?? '';
$senha  = $_POST['senha']  ?? '';

try {
    $sql  = "SELECT nome, senha_hash FROM directores WHERE codigo_acesso = :codigo AND status = true";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['codigo' => $codigo]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && $senha === $admin['senha_hash']) {
        $_SESSION['adminLog']  = true;
        $_SESSION['adminNome'] = $admin['nome'];
        header('Location: ../dashboards/dashboard_admin.php');
    } else {
        header('Location: ../login.php?erro=1');
    }
    exit();
} catch (PDOException $e) {
    header('Location: ../login.php?erro=1');
    exit();
}
